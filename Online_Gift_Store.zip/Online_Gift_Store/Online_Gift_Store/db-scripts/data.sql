-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ecommerce-db
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `address` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `zip_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,'HYDERABAD/TELANGANA/INDIA','India','Telangana','Brundhavan Colony','500075'),(2,'HYDERABAD/TELANGANA/INDIA','India','Telangana','Brundhavan Colony','500075');
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country` (
  `id` int NOT NULL,
  `code` varchar(2) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'BR','Brazil'),(2,'CA','Canada'),(3,'DE','Germany'),(4,'IN','India'),(5,'TR','Turkey'),(6,'US','United States');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` bigint DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item`
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `image_url` varchar(255) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `unit_price` decimal(38,2) DEFAULT NULL,
  `order_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `K_order_id` (`order_id`),
  KEY `FK_product_id` (`product_id`),
  CONSTRAINT `FK_order_id` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `FK_product_id` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item`
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_tracking_number` varchar(255) DEFAULT NULL,
  `total_price` decimal(38,2) DEFAULT NULL,
  `total_quantity` int DEFAULT NULL,
  `billing_address_id` bigint DEFAULT NULL,
  `customer_id` bigint DEFAULT NULL,
  `shipping_address_id` bigint DEFAULT NULL,
  `status` varchar(128) DEFAULT NULL,
  `date_created` datetime(6) DEFAULT NULL,
  `last_updated` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_billing_address_id` (`billing_address_id`),
  UNIQUE KEY `UK_shipping_address_id` (`shipping_address_id`),
  KEY `K_customer_id` (`customer_id`),
  CONSTRAINT `FK_billing_address_id` FOREIGN KEY (`billing_address_id`) REFERENCES `address` (`id`),
  CONSTRAINT `FK_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `FK_shipping_address_id` FOREIGN KEY (`shipping_address_id`) REFERENCES `address` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `unit_price` decimal(38,2) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `active` bit(1) DEFAULT b'1',
  `units_in_stock` int DEFAULT NULL,
  `date_created` datetime(6) DEFAULT NULL,
  `last_updated` datetime(6) DEFAULT NULL,
  `category_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_category` (`category_id`),
  CONSTRAINT `fk_category` FOREIGN KEY (`category_id`) REFERENCES `product_category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'TOYS-1000','ELECTRONIC CAR','Car 4*4 wheels',2900.00,'https://www.tiptopretail.com/cdn/shop/files/IMG-20231208_005429.jpg?v=1701977223',_binary '',100,'2024-10-29 10:58:31.000000',NULL,1),(2,'TOYS-1001','Dune Buggy 4X4 ','New 4 seater UTV Ride on car 24V Kids Electric Toy car',7990.00,'https://www.latoyz.com/cdn/shop/products/1_78665555-0a52-4416-806e-9c61c229e901_1024x1024@2x.jpg?v=1709596703',_binary '',100,'2024-10-29 10:58:31.000000',NULL,1),(3,'TOYS-1002','Lamborghini Veneno 2x12V 4X4 2 Seater','2024 UPGRADED DELUXE Kids Ride On Car with Remote Control',6990.00,'https://www.latoyz.com/cdn/shop/products/Green_1__98446_1617987097_1280_1280_jpeg_1024x1024@2x.jpg?v=1709595837',_binary '',100,'2024-10-29 10:58:31.000000',NULL,1),(4,'TOYS-1003','Dune Buggy 2X 2','Designed to comfortably fit two passengers, with ample legroom. You can tune in to your favorite music or podcasts with our high quality MP3 player.',9990.00,'https://www.torontotoys.ca/cdn/shop/products/1_949e22b9-7ba3-4f8b-8b7d-6957879abc90_1024x1024@2x.jpg?v=1645576298',_binary '',100,'2024-10-29 10:58:31.000000',NULL,1),(5,'TOYS-1004','Motor Bike Electronic','Children Electric Motorcycle Charging Electric Large Tricycle Stroller Ride on bike Electric for Kids 2-10 Years Old',28999.00,'https://samstoy.in/cdn/shop/files/Children-Electric-Motorcycle-Charging-Electric-Large-Tricycle-Stroller-Ride-on-bike-Electric-for-Kids-2-10-Years-Old-samstoy-in-4942.jpg?v=1724873890',_binary '',100,'2024-10-29 10:58:31.000000',NULL,1),(6,'TOYS-1005','Remote Control Car with Spray Lights - RC Cars for Kids','Remote Control Car with Spray Lights - Off-road RC Fun for Kids - Mist Smoke Effect, LED Lights, Perfect Gift for Birthdays and Christmas',1500.00,'https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcTerHXA0NwQhDnMKmdVlnEDCosNykBomHmW1Hod_wbbscoN0Dg7ZCVLhF90ZaFDS12Y5Mq6xJ6dZQII32p100Ff3Vh3Tx8sg-o2MdrDDQg&usqp=CAE',_binary '',100,'2024-10-29 10:58:31.000000',NULL,1),(7,'TOYS-1006','RareFind trove 1:24 RC Tractor 2.4G Remote Controlled Toy, 3.7V Li-ion Battery, Rubber Tyres,Green,Minimum Age 3 Years','? Lifelike Driving Experience? : Scale down the excitement with our meticulously detailed 1:24 scale RC Tractor. Its authentic design and realistic features bring the thrill of driving right to your fingertips.',990.00,'https://m.media-amazon.com/images/I/710Jw66AQ0L._SL1500_.jpg',_binary '',100,'2024-10-29 10:58:31.000000',NULL,1),(8,'TOYS-1007','Skyhawk Remote Control Helicopter DN029 ','20 mintues battery life Modular battery',99.00,'https://cdn-gnhif.nitrocdn.com/TVcQuMoyCLAXtNubQjipHiuZSBgcXCHY/assets/images/optimized/rev-b921d37/www.daddydrones.in/image/cache/catalog/SKYHAWK/FRONT/IMG_9138-500x500.JPG',_binary '',100,'2024-10-29 10:58:31.000000',NULL,1),(9,'TOYS-1008','LEGO Building Kit','The LEGO Classic 90 Years of Play 11021 Building Kit is a celebration of nine decades of LEGO creativity and innovation. ',6499.00,'https://hmadmin.hamleys.in/product/493176426/665/493176426-1.jpg',_binary '',100,'2024-10-29 10:58:31.000000',NULL,1),(10,'TOYS-1008','Funbee Toy Gun | Fun Target Shooting Gun','A realistic design that allows you to fire soft bullets with just a pull of the trigger, making it easy and safe to play with. Simply load the foam bullets into the gu, This toy set includes 10 foam bullets.',599.00,'https://baybee.co.in/cdn/shop/files/71wJT-CYRIL_500x.jpg?v=1716360855',_binary '',100,'2024-10-29 10:58:31.000000',NULL,1),(11,'WATCHES-1000','Fossil Machine Chronograph Black Dial Men’s Watch For Man Formal Casual ( Best Gift for Men )','Men Dial & Leather Straps Analogue Multi Function Watch BQ2879',21500.00,'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcQubsOGQoEYDVYnHD5hdGIpU2SEiJeCuN5gYb2ZOl_hQWFNKPH_hwrrvqHak93I1T6oAB1MiIDsbTO_CXJBoj7Lb-FnUHDq&usqp=CAY',_binary '',100,'2024-10-29 10:58:31.000000',NULL,2),(12,'WATCHES-1001','GUESS Mens Black Gold Tone Multi-function Watch','Keeping you on the edge of fashion, an octagonal case design with cut-thru dial details is complimented with a croco-leather on silicone signature flex strap.',18995.00,'https://watchfactory.in/cdn/shop/files/GW0492G3.webp?v=1729916059&width=1800',_binary '',100,'2024-10-29 10:58:31.000000',NULL,2),(13,'WATCHES-1002','Armani Exchange Men Black Hampton Analogue Watch AX2413','Elevate your style with this Men’s watch. This watch seamlessly combines sophistication with a sporty design, making it the perfect accessory for a polished and energetic look.',14999.00,'https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcQrfR91M3dbgDnqSXXD86yafU-sLaTM-X2xJGYnOfQymQ_KWO73h2jOcftiI_YdHWIkPQ43wsxjPQG98LVYNOB1JLA5f-Bb6Q3OEYo16Towx7KVatFTwRWsRw&usqp=CAE',_binary '',100,'2024-10-29 10:58:31.000000',NULL,2),(14,'WATCHES-1003','JOKER & WITCH Men Black Dial & Black Leather Straps Analogue Watch','Pack Contains: single watch Dial style: black solid round stainless steel dialComes in a signature JOKER & WITCH case',3999.00,'https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcSDMgkUoZFYs7q1Q5xQcRL-4NYcv_nT70xBVTDC6ZaZZBqR3u8asvfk2TwGO3IQvTWxz1aAYmiqQSJmK_25D-XhZABRxohvlRP8VQYBOVLxDZZm9rdSaZ_3&usqp=CAE',_binary '',100,'2024-10-29 10:58:31.000000',NULL,2),(15,'WATCHES-1004','SAMSUNG Watch','Introducing BP & ECG on Galaxy Watch : Keep a track of your well-being by monitoring and tracking your blood pressure & ECG easily and more conveniently',5999.00,'https://m.media-amazon.com/images/I/61euhYmH-4L._SX679_.jpg',_binary '',25,'2024-10-29 10:58:31.000000',NULL,2),(16,'WATCHES-1005','APPLE Watch Series 9','Apple Series-8 Ultra Smart Watch Series 8 Ultra Top Quality with Silicon OG Lock Belt On/Off Apple Logo Edition Dial: Silver Logo: On/Off ',30000.00,'https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcSfLyVJ7oAoif1TI2xEYQz9uUjqr0WPHZsf9-b9mcN60sacpgRVvBbqD1mvg8aAPA9qysHPpdJOOW6foN1EQ9cfngWtm2SmZN0pp82PACYWXdB4I27bSojuPkKmpzXso_KyJ-kI1g&usqp=CAc',_binary '',100,'2024-10-29 10:58:31.000000',NULL,2),(17,'WATCHES-1006','FASTRACK FR2  PRO','Styler FR2 Pro 1.43\" AMOLED Display Bluetooth Smartwatch ',999.00,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZGn-tLh-6aLEvkaVwgJq7q4vrMddZhZlmlQ&s',_binary '',100,'2024-10-29 10:58:31.000000',NULL,2),(18,'WATCHES-1007','NOISE HALO 2','NoiseFit Halo 2 Smartwatch',4999.00,'https://cdn.shopify.com/s/files/1/0997/6284/files/Halo-2-Carousel-1.webp?v=1725621156?width=600',_binary '',100,'2024-10-29 10:58:31.000000',NULL,2),(19,'WATCHES-1008','Louis Moinet','Louis Moinet Memorise18k Gold Limited Edition',51899.00,'https://cdn1.ethoswatches.com/media/catalog/product/cache/6e5de5bc3d185d8179cdc7258143f41a/l/o/louis-moinet-cosmic-art-lm-45-10b-ma-p-large.jpg',_binary '',100,'2024-10-29 10:58:31.000000',NULL,2),(20,'WATCHES-1009','TITAN ns1805qm04','Titan Neo Splash Quartz Multifunction Black Dial Stainless Steel Strap Watch for Men',5990.00,'https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Sites-titan-master-catalog/default/dw0814ec34/images/Titan/Catalog/1805QM04_1.jpg?sw=800&sh=800',_binary '',100,'2024-10-29 10:58:31.000000',NULL,2);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_category`
--

LOCK TABLES `product_category` WRITE;
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
INSERT INTO `product_category` VALUES (1,'Toys'),(2,'Watches');
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `state` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `country_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_country` (`country_id`),
  CONSTRAINT `fk_country` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `state`
--

LOCK TABLES `state` WRITE;
/*!40000 ALTER TABLE `state` DISABLE KEYS */;
INSERT INTO `state` VALUES (1,'Acre',1),(2,'Alagoas',1),(3,'Amapá',1),(4,'Amazonas',1),(5,'Bahia',1),(6,'Ceará',1),(7,'Distrito Federal',1),(8,'Espírito Santo',1),(9,'Goiás',1),(10,'Maranhão',1),(11,'Mato Grosso do Sul',1),(12,'Mato Grosso',1),(13,'Minas Gerais',1),(14,'Paraná',1),(15,'Paraíba',1),(16,'Pará',1),(17,'Pernambuco',1),(18,'Piaui',1),(19,'Rio de Janeiro',1),(20,'Rio Grande do Norte',1),(21,'Rio Grande do Sul',1),(22,'Rondônia',1),(23,'Roraima',1),(24,'Santa Catarina',1),(25,'Sergipe',1),(26,'São Paulo',1),(27,'Tocantins',1),(28,'Alberta',2),(29,'British Columbia',2),(30,'Manitoba',2),(31,'New Brunswick',2),(32,'Newfoundland and Labrador',2),(33,'Northwest Territories',2),(34,'Nova Scotia',2),(35,'Nunavut',2),(36,'Ontario',2),(37,'Prince Edward Island',2),(38,'Quebec',2),(39,'Saskatchewan',2),(40,'Yukon',2),(41,'Baden-Württemberg',3),(42,'Bavaria',3),(43,'Berlin',3),(44,'Brandenburg',3),(45,'Bremen',3),(46,'Hamburg',3),(47,'Hesse',3),(48,'Lower Saxony',3),(49,'Mecklenburg-Vorpommern',3),(50,'North Rhine-Westphalia',3),(51,'Rhineland-Palatinate',3),(52,'Saarland',3),(53,'Saxony',3),(54,'Saxony-Anhalt',3),(55,'Schleswig-Holstein',3),(56,'Thuringia',3),(57,'Andhra Pradesh',4),(58,'Arunachal Pradesh',4),(59,'Assam',4),(60,'Bihar',4),(61,'Chhattisgarh',4),(62,'Goa',4),(63,'Gujarat',4),(64,'Haryana',4),(65,'Himachal Pradesh',4),(66,'Jammu & Kashmir',4),(67,'Jharkhand',4),(68,'Karnataka',4),(69,'Kerala',4),(70,'Madhya Pradesh',4),(71,'Maharashtra',4),(72,'Manipur',4),(73,'Meghalaya',4),(74,'Mizoram',4),(75,'Nagaland',4),(76,'Odisha',4),(77,'Punjab',4),(78,'Rajasthan',4),(79,'Sikkim',4),(80,'Tamil Nadu',4),(81,'Telangana',4),(82,'Tripura',4),(83,'Uttar Pradesh',4),(84,'Uttarakhand',4),(85,'West Bengal',4),(86,'Andaman and Nicobar Islands',4),(87,'Chandigarh',4),(88,'Dadra and Nagar Haveli',4),(89,'Daman & Diu',4),(90,'Lakshadweep',4),(91,'Puducherry',4),(92,'The Government of NCT of Delhi',4),(93,'Alabama',6),(94,'Alaska',6),(95,'Arizona',6),(96,'Arkansas',6),(97,'California',6),(98,'Colorado',6),(99,'Connecticut',6),(100,'Delaware',6),(101,'District Of Columbia',6),(102,'Florida',6),(103,'Georgia',6),(104,'Hawaii',6),(105,'Idaho',6),(106,'Illinois',6),(107,'Indiana',6),(108,'Iowa',6),(109,'Kansas',6),(110,'Kentucky',6),(111,'Louisiana',6),(112,'Maine',6),(113,'Maryland',6),(114,'Massachusetts',6),(115,'Michigan',6),(116,'Minnesota',6),(117,'Mississippi',6),(118,'Missouri',6),(119,'Montana',6),(120,'Nebraska',6),(121,'Nevada',6),(122,'New Hampshire',6),(123,'New Jersey',6),(124,'New Mexico',6),(125,'New York',6),(126,'North Carolina',6),(127,'North Dakota',6),(128,'Ohio',6),(129,'Oklahoma',6),(130,'Oregon',6),(131,'Pennsylvania',6),(132,'Rhode Island',6),(133,'South Carolina',6),(134,'South Dakota',6),(135,'Tennessee',6),(136,'Texas',6),(137,'Utah',6),(138,'Vermont',6),(139,'Virginia',6),(140,'Washington',6),(141,'West Virginia',6),(142,'Wisconsin',6),(143,'Wyoming',6),(144,'Adıyaman',5),(145,'Afyonkarahisar',5),(146,'Ağrı',5),(147,'Aksaray',5),(148,'Amasya',5),(149,'Ankara',5),(150,'Antalya',5),(151,'Ardahan',5),(152,'Artvin',5),(153,'Aydın',5),(154,'Balıkesir',5),(155,'Bartın',5),(156,'Batman',5),(157,'Bayburt',5),(158,'Bilecik',5),(159,'Bingöl',5),(160,'Bitlis',5),(161,'Bolu',5),(162,'Burdur',5),(163,'Bursa',5),(164,'Çanakkale',5),(165,'Çankırı',5),(166,'Çorum',5),(167,'Denizli',5),(168,'Diyarbakır',5),(169,'Düzce',5),(170,'Edirne',5),(171,'Elazığ',5),(172,'Erzincan',5),(173,'Erzurum',5),(174,'Eskişehir',5),(175,'Gaziantep',5),(176,'Giresun',5),(177,'Gümüşhane',5),(178,'Hakkâri',5),(179,'Hatay',5),(180,'Iğdır',5),(181,'Isparta',5),(182,'İstanbul',5),(183,'İzmir',5),(184,'Kahramanmaraş',5),(185,'Karabük',5),(186,'Karaman',5),(187,'Kars',5),(188,'Kastamonu',5),(189,'Kayseri',5),(190,'Kırıkkale',5),(191,'Kırklareli',5),(192,'Kırşehir',5),(193,'Kilis',5),(194,'Kocaeli',5),(195,'Konya',5),(196,'Kütahya',5),(197,'Malatya',5),(198,'Manisa',5),(199,'Mardin',5),(200,'Mersin',5),(201,'Muğla',5),(202,'Muş',5),(203,'Nevşehir',5),(204,'Niğde',5),(205,'Ordu',5),(206,'Osmaniye',5),(207,'Rize',5),(208,'Sakarya',5),(209,'Samsun',5),(210,'Siirt',5),(211,'Sinop',5),(212,'Sivas',5),(213,'Şanlıurfa',5),(214,'Şırnak',5),(215,'Tekirdağ',5),(216,'Tokat',5),(217,'Trabzon',5),(218,'Tunceli',5),(219,'Uşak',5),(220,'Van',5),(221,'Yalova',5),(222,'Yozgat',5),(223,'Zonguldak',5);
/*!40000 ALTER TABLE `state` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-30 12:18:34
